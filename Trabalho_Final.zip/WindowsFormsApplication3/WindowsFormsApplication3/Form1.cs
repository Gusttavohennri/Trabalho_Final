﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Collections;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Frmcrud : Form
    {
        ArrayList Cadastro = new ArrayList();

        public Frmcrud()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
        private void CarregaGrid()
        {
            dgvDados.DataSource = null;
            dgvDados.DataSource = Cadastro;
            dgvDados.ClearSelection();
            dgvDados.Columns[0].Width = 140;
            dgvDados.Columns[1].Width = 140;
            dgvDados.Columns[2].Width = 80;
            dgvDados.Columns[3].Width = 120;

        }

        private void btnIncluir_Click(object sender, EventArgs e)
        {
            Aluno x = new Aluno();

            x.Nome = "Digite os Dados do aluno >";
            x.Endereco = "";
            x.Tel = "";
            x.Mail = "";

            Cadastro.Add(x);
            CarregaGrid();

            //dgvDados.CurrentCell = dgvDados.Rows[dgvDados.RowCount - 1].Cells[0];
        }

        private void dgvDados_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            Aluno x = new Aluno();
            x.Nome = dgvDados.CurrentRow.Cells[0].Value.ToString();
            x.Endereco = dgvDados.CurrentRow.Cells[1].Value.ToString();
            x.Tel = dgvDados.CurrentRow.Cells[2].Value.ToString();
            x.Mail = dgvDados.CurrentRow.Cells[3].Value.ToString();

            Cadastro[dgvDados.CurrentRow.Index] = x;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            Cadastro.RemoveAt(dgvDados.CurrentRow.Index);
            CarregaGrid();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            string Nome = txtPesquisar.Text;
            bool Acha = false;
            txtPesquisar.Text = "";
            dgvDados.ClearSelection();

            for (int i = 0; i < dgvDados.RowCount; i++)
            {
                if (dgvDados.Rows[i].Cells[0].Value.ToString()==Nome)
                {
                    dgvDados.CurrentCell = dgvDados.Rows[i].Cells[0];
                    Acha = true;
                }
            }
            if (!Acha)
                txtPesquisar.Text = "Não possui....";
        }
    }
}
